const discord = require('discord.js');

const bot = new discord.Client();

bot.on('ready', () => {
    console.log('Snipe YT - Bot is online!');
    bot.user.setActivity('GTA 6', {type:'PLAYING'}).catch(console.error);
});



bot.login('ODIxMzU4MDUwMTg2MzYyODkw.YFCjSw.iQWV0TKM-ZsjdWMRZC9DHHvtDPs');

